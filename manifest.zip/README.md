TODO:

- [X] Add controls to reels
- [X] Add controls to posts
- [X] Add controls to direct
- [ ] Keep reels information
- [ ] Add controls to stories
  > Today the account information, description, music, etc are being removed to accommodate controls
- Get user data
  - [ ] Initial volume
  - [ ] Autoplay on/off
  - [ ] Loop/Pause at end 


